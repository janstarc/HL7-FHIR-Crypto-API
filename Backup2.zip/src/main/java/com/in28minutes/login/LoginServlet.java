package com.in28minutes.login;

import com.in28minutes.login.LoginService;
import com.in28minutes.todo.TodoService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/login.do")
public class LoginServlet extends HttpServlet {

    private LoginService uvService = new LoginService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String name = request.getParameter("name");
        String pass = request.getParameter("password");

        if(uvService.isUserValid(name, pass)){
            request.getSession().setAttribute("name", name);
            response.sendRedirect("/list-todo.do");      // Equivalent to viewHelper::render

        } else {
            request.setAttribute("success", "Your un and pass don't match");
            request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
        }



    }


}
